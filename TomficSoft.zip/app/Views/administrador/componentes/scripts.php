<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.4/jquery-ui.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>
<script src="<?= base_url('js/scripts/overhang.min.js') ?>"></script>
<script src="<?= base_url('js/scripts/datatable.js') ?>"></script>
<script>
    var baseurl = '<?= base_url() ?>';
</script>