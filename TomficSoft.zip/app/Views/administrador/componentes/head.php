<link
  href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css"
  rel="stylesheet"
  crossorigin="anonymous"
>
<link rel="stylesheet" href="<?= base_url('css/estilo.css') ?>">
<link rel="stylesheet" href="<?= base_url('css/material.css') ?>">
<link rel="stylesheet" href="<?= base_url('fontawesome/css/fontawesome.min.css') ?>">
<link rel="stylesheet" href="<?= base_url('fontawesome/css/brands.css') ?>">
<link rel="stylesheet" href="<?= base_url('fontawesome/css/solid.css') ?>">
<link rel="stylesheet" href="<?= base_url('css/overhang.min.css') ?>">
<link rel="stylesheet" href="<?= base_url('css/datatable.css') ?>">